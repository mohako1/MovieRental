using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace MovieRentalSoftware
{
    public partial class AdminPanel : Form
    {
        private int adminId;
        private Movie_Rental_ManagementDataSetTableAdapters.MOVIETableAdapter movieTableAdapter;
        private Movie_Rental_ManagementDataSetTableAdapters.SUPPLIERTableAdapter supplierTableAdapter;
        private Movie_Rental_ManagementDataSet.MOVIEDataTable movieTable;
        private Movie_Rental_ManagementDataSet.SUPPLIERDataTable supplierTable;

        public AdminPanel(int adminId)
        {
            InitializeComponent();
            this.adminId = adminId;
            LoadMovies();
        }

        private void LoadMovies()
        {
            movieTableAdapter = new Movie_Rental_ManagementDataSetTableAdapters.MOVIETableAdapter();
            movieTable = new Movie_Rental_ManagementDataSet.MOVIEDataTable();
            movieTableAdapter.Fill(movieTable);
            dataGridViewMovies.DataSource = movieTable;
        }

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            var addMovieForm = new AddEditMovieForm(adminId);
            if (addMovieForm.ShowDialog() == DialogResult.OK)
            {
                LoadMovies();
            }
        }

        private void btnEditMovie_Click(object sender, EventArgs e)
        {
            if (dataGridViewMovies.SelectedRows.Count > 0)
            {
                int movieId = Convert.ToInt32(dataGridViewMovies.SelectedRows[0].Cells["MOVIE_ID"].Value);
                var editMovieForm = new AddEditMovieForm(adminId, movieId);
                if (editMovieForm.ShowDialog() == DialogResult.OK)
                {
                    LoadMovies();
                }
            }
        }

        private void btnDeleteMovie_Click(object sender, EventArgs e)
        {
            if (dataGridViewMovies.SelectedRows.Count > 0)
            {
                int movieId = Convert.ToInt32(dataGridViewMovies.SelectedRows[0].Cells["MOVIE_ID"].Value);
                var row = movieTable.FindByMOVIE_ID(movieId);
                if (row != null)
                {
                    row.Delete();
                    movieTableAdapter.Update(movieTable);
                    LoadMovies();
                }
            }
        }
    }
} 